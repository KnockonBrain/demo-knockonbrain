<?php
session_start();

include "connection.php";


$userid=$_GET['userid'];
$id=$_GET['id'];


$sql = mysqli_query($link,"SELECT * FROM questions WHERE id='" .$userid. "'");
$question='';
$question_no='';
$opt1='';
$opt2='';
$opt3='';
$opt4='';
$answer='';
$level='';
if ($sql) 
{
    // header("location: add_edit_questions.php?id=$id");
       while($row=mysqli_fetch_array($sql))
    {
        $question=$row["question"]; 
        $question_no=$row["question_no"];
        $opt1=$row["opt1"]; 
        $opt2=$row["opt2"]; 
        $opt3=$row["opt3"]; 
        $opt4=$row["opt4"]; 
        $answer=$row["answer"]; 
        $level=$row["level"]; 

    }
    
        
   

} else {
    echo "Error: " . mysqli_error($link);
}
?>

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/80d99e7a2a.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Update Question</title>
   <link rel=" icon" type="image/jpg" href="../images/fevicon.jpg"/>
    <style>
        * {
            padding: 0;
            margin: 0;
            text-decoration: none;
            list-style: none;
            box-sizing: border-box;
            font-family: 'Open Sans', sans-serif;
        }
body
{
    background-color: whitesmoke;
}
        .roww:after {
            content: "";
            display: table;
            clear: both;
        }

        nav
            {
                top:0;
                position: absolute;
                z-index: 1;
                background-color: #2B3856;
                height: 65px;
                width: 100%;
                box-sizing: border-box;
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            }
            .toggle, #toggle-item
            {
                display: none;
            }
            nav .cull
            {
                margin:11px 0 0 0px;
                float: left;
                color:white;
            }
            nav .cull h1
            {
                font-size: 45px;
                font-family: "Gabriola", serif;
                font-weight:bold;
            }
            nav .cul
            {
                margin-top: 15px;
                margin-right: 20px;
                
                float: right;
            }
            
            nav ul li
            {
                display: inline-block;
                margin: 0 5px;
                font-family: "Podkova", serif;
            }
            nav .cul .icon
            {
                color:white;
                border: 2px solid white;
                padding: 10px;
                border-radius: 50%;
                font-size: 17px;
            }
            nav .cul .icon:hover
            {
                transition: .5s;
                color:#cccccc;
                border: 2px solid #cccccc;
            }
            nav ul li a
            {
                color:white;
                font-size: 19px;
                padding: 7px 10px;
                border-radius: 3px;
                font-weight:100;
                text-decoration: none;
            }
            nav ul li a:hover
            {
                transition: .5s;
                color: #cccccc;
            }
        .bcontainer
        {
            width: 900px;
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
            margin: auto;
            margin-top: 90px;
            background-color: white;
        }
        .image
        {
            background-position: center; 
            background-size: cover; 
            position: relative;
            background-image:url(images/getty_496612468_2000138820009280460_336567.jpg);
            float: left;
            width: 40%;
            height:540px;
        }
        .image h3
        {
            font-size: 46px;
            font-weight: normal;
            margin-top: 200px;
            text-align: center;
        }
        .addpage
        {
            width: 60%;
            float: right;
            padding: 40px 0 40px 40px ; 
        }

        .addpage .form
        {
            width: 500px;
            margin: auto;
        }
        .addpage h2
        {
            font-weight: normal;
            font-size: 35px;
            margin-bottom: 30px;
        }
        .addpage .boxx
        {
            float: left;
            margin-right: 50px;
        }
        .addpage .boxxx
        {
            float: left;
            width: 194px;
        }
        .addpage label
        {
            font-size: 14px;
            font-weight: bold;
        }
        .addpage .text
        {
            width: 100%;
            margin:10px 0 15px;
            border: 1px solid gray;
            border-top-style: hidden;
            border-right-style: hidden;
            border-left-style: hidden;
            padding: 0px 0 10px;
        }
        .addpage .tex
        {
            padding-bottom: 15px;
        }
        .addpage .textt
        {
            width: 88%;
            margin:10px 0 15px;
            border: 1px solid gray;
            border-top-style: hidden;
            border-right-style: hidden;
            border-left-style: hidden;
            padding: 0px 0 10px;
        }
        .addpage .text:focus
        {
            outline: none;
        }
        .addpage .textt:focus
        {
            outline: none;
        }
        .addpage .btnn
        {
            text-align: center;
        }
        .addpage button
        {
            padding: 12px 10px;
            cursor: pointer;
            font-size: 17px;
            outline: none;
            border:none;
            background-color:#103F6E;
            color: white;
            border: 5px;
            margin-top: 15px;
        }
        .addpage button:hover
        {
            background-color:#43b2f0;
            cursor: pointer;
        }
        @media (max-width:950px)
        {
            .bcontainer
            {
                width:600px;
                margin-bottom: 20px;
            }
            .image
            {
                height:785px;
            }
            .addpage .boxx
            {
                float: none;
                margin-right: 0;
            }
            .addpage .boxxx
            {
                float: none;
                width: 100%;
            }
            .addpage .form
            {
                width: 350px;
            }
            .addpage .textt
            {
                width: 80%;
            }
            .addpage .text
            {
                width: 80%;
            }
        }
        @media (max-width:680px)
        {
            .bcontainer
            {
                width: auto;
                box-shadow: none;
                margin: auto;
                margin-top: 100px;
                background-color: white;
            }
            .image
            {
                height:500px;
                float: none;
                width: auto;
            }
            .image h3
            {
                margin-top: 0;
                padding-top: 200px;
            }
            .addpage
            {
                margin-top: 50px;
                float: none;
                width: auto;
                padding: 20px 30px 20px 30px;
            }
           .addpage .form
            {
                width: auto;
            }
            .addpage .textt
            {
                width: 100%;
            }
            .addpage .text
            {
                width: 100%;
            }
        }
        @media (max-width:805px)
            {
                nav .cul
                {
                    display: none;
                }
                .toggle
                {
                    display: block;
                    width: 100%;
                }
                .openbtn 
                {
                    display: block;
                    font-size: 28px;
                    cursor: pointer;
                    padding: 5px 10px 7px;
                    border: 1px solid white;
                    border-radius: 5px;
                    background-color: #103F6E;
                    margin:12px 30px 0;
                    color:white;
                    float: right;
                }
                .openbtn:hover
                {
                    
                }
                #toggle-item
                {
                    width:100%;
                    background-color: #2B3856;
                    top:56px;
                    position: absolute;
                }
                .toggle-item .item
                {
                    z-index:0;
                    text-align: center;
                    font-size: 22px;
                    width: 100%;
                    border: 2px solid white;
                    padding: 10px;
                    border-top:hidden;
                    border-left:hidden;
                    border-right:hidden;
                }
                .toggle-item .item a
                {
                    cursor: pointer;
                    width: 100%;
                    color:white;
                    text-decoration: none;
                }
                .toggle-item .item a:hover
                {
                    color:#999999;
                }
            }
        
    </style>
</head>

<body>
        <nav>
            <div class="roww">
                <div class="toggle">
                    <button class="openbtn" id="nav-toggle" onclick="openNav()" ><i class="fas fa-bars icon"></i></button>  
                </div>
                <div class="cull" style="margin:9px 0px 0 10px;">
                <img alt="giit solutions" src="images/Knockonbrain logo (1).png"> &nbsp;
                </div>
                <div class="cull">
                    
                    <h1>KnockOnBrain</h1>
                </div>
                <ul class="cul">
                    <li><a href="https://knockonbrain.com/CLient/test.php">Schedule Test</a></li>
            <li><a href="addexamm.php">Create Test</a></li>
            <li><a href="../CLient/logout.php">Logout</a></li>
            <li><div><a href="../CLient/profile.php"><i class="fas fa-user icon"></i></a></div></li>
                </ul>
            </div>
            <div class="toggle-item" id="toggle-item">
                <div class="item"></div>
                <div class="item"><a href="https://knockonbrain.com/CLient/test.php">Schedule Test</a></div>
            <div class="item"><a href="addexamm.php">Create Test</a></div>
            <div class="item"><a href="../CLient/logout.php">Logout</a></div>
            <div class="item"><a href="../CLient/profile.php">Your Profile</a></div>
            </div>
        </nav>
   
    <script>
        $(document).ready(function () {
            $('#nav-toggle').click(function (e) {
                e.preventDefault();
                e.stopPropagation();
                $('#toggle-item').toggle();
            });
            $('#toggle-item').click(function (e) {
                e.stopPropagation();
            });
            $('body').click(function () {
                $('#toggle-item').hide();
            });
        });
    </script>
      <section>
            <div class="bcontainer">
                <div class="roww">
                <div class="image">
                    <h3> Update Questions </h3>
                </div>
                <form action="" name="form1" method="post">
                <div class="addpage">
                    
                <div class="form">
                        <h2> Update questions</h2>
                        <div><label>Add Question </label></div>
                        <input type="text" name="question" class=" textt" placeholder="Question" value="<?php  echo $question; ?>" required>
                    
                    <div class="roww">
                        <div class="boxx">
                            <div><label> Add Option1 </label></div>
                            <input type="text" name="opt1" class="text" placeholder="Option1" value="<?php  echo $opt1; ?>" required>
                        </div>
                        <div class="boxx">
                            <div><label> Add Option2</label></div>
                            <input type="text" name="opt2" class="text" placeholder="Option2" value="<?php  echo $opt2; ?>" required>
                        </div>
                    </div>
                    <div class="roww">
                        <div class="boxx">
                            <div><label> Add Option3</label></div>
                            <input type="text" name="opt3" class="text" placeholder="Option3" value="<?php  echo $opt3; ?>" required>
                        </div>
                        <div class="boxx">
                            <div><label> Add Option4 </label></div>
                            <input type="text" name="opt4" class="text" placeholder="Option4" value="<?php  echo $opt4; ?>"  required>
                        </div>
                    </div>
                    <div class="roww">
                        <div class="boxx">
                            <div><label> Add Answer </label></div>
                            <input type="text" name="answer" class=" text" placeholder="Answer" value="<?php  echo $answer; ?>" required>
                        </div>
                        <div class="boxxx">
                            <div><label> Add Level </label></div>
                            <select class= "text tex" name="level" value="Add Level" required>
                        
                            <option value="Easy">Easy</option>
                            <option value="Medium">Medium</option>
                            <option value="Hard">Hard</option>
			                </select>
                        </div>
                    </div>   
                    
                        <div class="btnn"><button name="submit1" class="btn">Update Question</button></div>
                </div>
                    </div>
                       </form>
                    </div>
            </div>
        </section>
        
        
        
          <?php
         if(isset($_POST["submit1"]))

            {    
                $id=$_GET['id'];
                $sql="update questions set question='".$_POST['question']."',opt1='".$_POST['opt1']."',opt2='".$_POST['opt2']."',opt3='".$_POST['opt3']."',opt4='".$_POST['opt4']."',answer='".$_POST['answer']."',level='".$_POST['level']."' WHERE id='" . $_GET["userid"] . "'";
                mysqli_query($link,$sql) or die(mysqli_error($link));
                


                   ?>
                <script type="text/javascript">
                   window.location='addquess.php?userid='+"<?php echo $id;?>";
                      
                //    window.location='add_edit_questions.php?id='+"<?php echo $id; ?>";
                </script>
               <?php
                 





            
            }
        ?>
</body>

</html>