<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CLIENTS</title>
    
     <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
</head>

<body>
    <header id="header" class="header">

            <div class="header-menu">

               
                    
                                                       <div class="col-12">
                                                                    <nav class="navbar navbar-expand-xl class="navbar navbar-dark bg-dark"">
                                                                        
                                                
                                                                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                                                            <ul class="navbar-nav mx-auto">
                                                                                <li class="nav-item">
                                                                                <a class="dropdown-item" href="https://phptest.avianglobes.com/CLient/test.php" ><strong>Send invite</strong>
                                                                                         
                                                                                    </a>
                                                                                </li>
                                                                               
                                                                                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                                                                
                                                                                <li class="nav-item ">
                                                                                    <a class="dropdown-item" href="exam_category.php"><strong>Add Exam</strong> </a>
                                                                                </li>
                                                                               
                                                                               
                                                
                                                                               
                                                                            </ul>
                                                                            <ul class="navbar-nav">
                                                                                <li class="nav-item">
                                                                                    <a class="nav-link d-flex" href="../CLient/logout.php">
                                                                                        Logout</i>
                                                                                        </a>
                                                                                </li>
                                                                            </ul>
                                                                        </div>
                                                                    </nav>
                                                                </div>
            
                        

                        

                        
                    </div>
                </div>
     </header>       
                                                                