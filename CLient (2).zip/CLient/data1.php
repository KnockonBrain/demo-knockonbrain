<?php
$dbhost = 'localhost';
$dbname = 'giitsolu_testphpdb';
$dbusername = 'giitsolu_testphpdb';
$dbpassword = 'A!i-E_MjibT{';

$pdo = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbusername, $dbpassword);
$con1 = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);
?>