<?php
session_start();
if(isset($_SESSION['ID'])) {
    
    include "connection.php";
    session_start();
    $cid=$_SESSION['ID'];
    $username=$_SESSION['user_nicename'];


?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://kit.fontawesome.com/80d99e7a2a.js" crossorigin="anonymous"></script>
       <link rel=" icon" type="image/jpg" href="../images/fevicon.jpg"/>
<style>
            *
            {
                padding: 0;
                margin: 0;
                text-decoration: none;
                list-style: none;
                box-sizing: border-box;
                font-family:'Open Sans',sans-serif;
            }
            .roww:after 
            {
                content: "";
                display: table;
                clear: both;
            }
            nav
            {
                top:0;
                position: absolute;
                z-index: 1;
                background-color: #2B3856;
                height: 65px;
                width: 100%;
                box-sizing: border-box;
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            }
            .toggle, #toggle-item
            {
                display: none;
            }
            nav .cull
            {
                margin:11px 0 0 0px;
                float: left;
                color:white;
            }
            nav .cull h1
            {
                font-size: 45px;
                font-family: "Gabriola", serif;
                font-weight:bold;
            }
            nav .cul
            {
                margin-top: 15px;
                margin-right: 20px;
                
                float: right;
            }
            
            nav ul li
            {
                display: inline-block;
                margin: 0 5px;
                font-family: "Podkova", serif;
            }
            nav .cul .icon
            {
                color:white;
                border: 2px solid white;
                padding: 10px;
                border-radius: 50%;
                font-size: 17px;
            }
            nav .cul .icon:hover
            {
                transition: .5s;
                color:#cccccc;
                border: 2px solid #cccccc;
            }
            nav ul li a
            {
                color:white;
                font-size: 19px;
                padding: 7px 10px;
                border-radius: 3px;
                font-weight:100;
                text-decoration: none;
            }
            nav ul li a:hover
            {
                transition: .5s;
                color: #cccccc;
            }
            .head
            {
                background-position: center; 
                background-size: cover; 
                position: relative;
                background-image:linear-gradient( rgba(0, 12, 45, 0.5), rgba(0, 12, 45, 0.5) ),url(images/green-chameleon-s9CC2SKySJM-unsplash.jpg);
                margin: 0;
                padding:0;
            }
            .head h1
            {
                padding: 120px 0 50px;
                color: white;
                font-size: 47px;
                margin: auto;
                text-align: center;
                
            }
            a 
            { color: inherit; 
                text-decoration:none;
            }
            a:hover
            {
                color:white;
            }
            #add
                {
                   background-color:#103F6E;
                   border:1px solid #103F6E;
                }
                #add:hover
                {
                    background-color:#43b2f0;
                    border:1px solid #43b2f0;
                }
            @media (max-width:940px)
            {
                nav .cul
                {
                    display: none;
                }
                .toggle
                {
                    display: block;
                    width: 100%;
                }
                .openbtn 
                {
                    display: block;
                    font-size: 28px;
                    cursor: pointer;
                    padding: 0px 10px;
                    border: 1px solid white;
                    border-radius: 5px;
                    background-color: #103F6E;
                    margin:12px 30px 0;
                    color:white;
                    float: right;
                }
                .openbtn:hover
                {
                    
                }
                #toggle-item
                {
                    width:100%;
                    background-color: #2B3856;
                    top:56px;
                    position: absolute;
                }
                .toggle-item .item
                {
                    z-index:0;
                    text-align: center;
                    font-size: 22px;
                    width: 100%;
                    border: 2px solid white;
                    padding: 10px;
                    border-top:hidden;
                    border-left:hidden;
                    border-right:hidden;
                }
                .toggle-item .item a
                {
                    cursor: pointer;
                    width: 100%;
                    color:white;
                }
                .toggle-item .item a:hover
                {
                    color:#999999;
                }
            }
            </style>
    <title>Create Test Category</title>
</head>

<body>
 

        <nav>
            <div class="roww">
                <div class="toggle">
                    <button class="openbtn" id="nav-toggle" onclick="openNav()" ><i class="fas fa-bars icon"></i></button>  
                </div>
                <div class="cull" style="margin:9px 0px 0 10px;">
                <img alt="giit solutions" src="images/Knockonbrain logo (1).png"> &nbsp;
                </div>
                <div class="cull">
                    <h1>KnockOnBrain</h1>
                </div>
                <ul class="cul">
                    <li><a href="https://knockonbrain.com/CLient/test.php">Schedule Test</a></li>
                    <li><a href="addexamm.php">Create Test</a></li>
                    <li><a href="../final2.php">View Result</a></a></li>
                    <li><a href="../CLient/logout.php">Logout</a></li>
                    <li><div><a href="../CLient/profile.php"><i class="fas fa-user icon"></i></a></div></li>
                </ul>
            </div>
            
            <div class="toggle-item" id="toggle-item">
                <div class="item"></div>
                <div class="item"><a href="https://knockonbrain.com/CLient/test.php">Schedule Test</a></div>
                <div class="item"><a href="addexamm.php">Create Test</a></div>
                <div class="item"><a href="../final2.php">View Result</a></div>
                <div class="item"><a href="../CLient/logout.php">Logout</a></div>
                <div class="item"><a href="../CLient/profile.php">Your Profile</a></div>
            </div>
            
        </nav>
    
    
       
                            <script>
                                $(document).ready(function()
                                    {
                                        $('#nav-toggle').click( function(e) 
                                        {
                                            e.preventDefault();
                                            e.stopPropagation(); 
                                            $('#toggle-item').toggle();
                                        });
                                        $('#toggle-item').click( function(e) 
                                        {
                                            e.stopPropagation(); 
                                        });
                                        $('body').click( function() 
                                        {
                                            $('#toggle-item').hide();
                                        });
                                    });   
                            </script>
        <section class="head">
            <h1> Add Test</h1>
        </section>
                            
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-5 col-sm-6">
                <div class="row" style="width: 100%;">
                    <p style="background-color: rgba(128, 128, 128, 0.322); font-weight: bold; margin-left: 12px;">Create Test</p>
                </div>
                <form action="" name="form1" method="post" class="mb-3" style="background-color: rgba(128, 128, 128, 0.103); padding:10px">
                    <div class="mb-3">
                        <label class="mb-2">Enter Test Name</label>
                        <input class="form-control" name="examname" type="text" placeholder="e.g. Digital Marketing" required>
                    </div>
                    <div class="mb-3">
                        <label class="mb-2" required>Select Duration of Test</label>
                        <select class="form-select" name="examtime">
                            <option value="10 ">10 Minutes</option>
                            <option value="20 ">20 Minutes</option>
                            <option value="30">30 Minutes</option>
                          </select>
                    </div>
                    <div class="mb-3">
                        <label class="mb-2" required>Number of Question</label>
                        <select class="form-select" name="noq">
                            <option value="10 ">10 Questions</option>
                            <option value="20 ">20 Questions</option>
                        
                          </select>
                    </div>
                    <button type="submit" name="submit1" class="btn btn-primary" id="add">Add Test</button>
                </form>
            </div>
            <div class="col-md-7 col-sm-6">
                <div class="row">
                    <center><p style="background-color: rgba(128, 128, 128, 0.322); font-weight: bold;">Test</p></center>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-responsive-lg table-lg" style="border: 1px;">
                        <thead>
                            <tr>
                                <th scope="col">Sr.No.</th>
                                <th scope="col">Test Name</th>
                                <th scope="col">Test Duration</th>
                                <th scope="col">Set of Questions</th>
                                <th scope="col">Add Questions</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                                                                                $count=0;
                                                                                $res=mysqli_query($link,"select * from exam_category where cid = '$cid'");
                                                                                while($row=mysqli_fetch_array($res))
                                                                                {
                                                                                    $count=$count+1;
                                                                                    ?>
                                                                                     <tr>
                                                                                    <th scope="row"><?php echo $count ?></th>
                                                                                    <td><?php echo $row['category']; ?></td>
                                                                                    <td><?php echo $row['exam_time_in_minutes']; ?></td>
                                                                                    <td><?php echo $row['noq']; ?></td>
                                                                                    <td><button type="button" class="btn btn-primary" id="add" ><a href="addquess.php?userid=<?php echo $row['id']; ?>">Add</a></button></td>
                                                                                    <td><button type="button" class="btn btn-danger"><a href="delete.php?userid=<?php echo $row["id"]; ?>"  onclick="return confirm('Are you sure?');" >Delete</a></button></td>
                                                                                    <!--
                                                                                    <td><a href="addquess.php?userid=<?php echo $row['id']; ?>">Add Questions</a></td>
                                                                                    <td><a href="delete.php?userid=<?php echo $row["id"]; ?>"  onclick="return confirm('Are you sure?');" >Delete</a>
                                                                                    -->
                                                                                    </td>
                                        
                                                                                </tr>
                                                                                       <?php
                                                                                }
                                        
                                        
                                        
                                                                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php
         if(isset($_POST["submit1"]))
            {   
                $query="insert into exam_category values(NULL,'$_POST[examname]','$_POST[examtime]','$_POST[noq]','https://knockonbrain.com/php/test/index.php', '$username', $cid)";
                mysqli_query($link,$query) or die(mysqli_error($link));
                   ?>
                <script type="text/javascript">
                    //   alert("exam added successfuly");
                      window.location.href=window.location.href;
                </script>
               <?php

            
            }
?>
<?php
}else echo "<h1>Please login first .</h1>";
?>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>